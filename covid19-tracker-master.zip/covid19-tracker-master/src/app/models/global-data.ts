export interface GlobalDataSummary {
    country ?: string,
    confirmed ?: number,
    deaths ?: number,
    active ?: number,
    recovered ?: number
}