export interface DateWiseDataModel {
    country ?: string,
    cases ?: number,
    date ?: Date
}
